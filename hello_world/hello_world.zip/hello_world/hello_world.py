#task 1
print('matthew baiamonte')

#task 2
name='Noelle'
print( "hello", name)
print('hello'+ ' '+ name)

#task 3
num = 42
print('hello' + ' ' + str(num))
print('hello', num)

#task 4
fav_food_a='sushi'
fav_food_b='pizza'
print('I love to eat {} and {}.'.format(fav_food_a, fav_food_b))
print(f'I love to eat {fav_food_a} and {fav_food_b}')